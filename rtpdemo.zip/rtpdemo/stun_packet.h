#pragma once

#include "stun_common.h"
#include <unordered_map>
#include <string>

class StunPacket
{
public:
	StunPacket();
	virtual ~StunPacket();

	bool Parse(const uint8_t* data, size_t size);
	std::string GetAttrUserName() const;
	std::string GetMessageIntegrity() const;

	std::vector<uint8_t> Build();
	void SetAttribute(StunAttributeType attr, uint32_t value_uint, std::string value_str);

private:
	uint16_t message_type_ = STUN_MESSAGE_UNKNOW;
	uint32_t message_length_ = 0;
	uint32_t mapped_addr_ = 0;
	uint32_t mapped_port_ = 0;
	uint32_t magic_cookie_ = 0;
	uint32_t priority_ = 0;
	std::string transaction_id_;
	std::string username_;
	std::string password_;
	std::string message_integrity_;
	std::unordered_map<StunAttributeType, std::pair<std::string, uint32_t>> attrs_;
};

