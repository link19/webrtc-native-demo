#pragma once

#include "rtcp_common.h"
#include <vector>

class RtcpSender
{
public:
	RtcpSender();
	virtual ~RtcpSender();

	void SetOption(int option, int value);
	std::vector<uint8_t> Build();
	std::vector<uint8_t> BuildSR();

private:
	RtcpHeader rtcp_header_ = {};
	uint32_t ssrc_ = 0;
	uint32_t ntp_timestamp_ = 0;
	uint32_t ntp_mword_ = 0;
	uint32_t ntp_lword_ = 0;
	uint64_t rtp_timestamp_ = 0;
	uint32_t sent_pkt_cnt_ = 0;
	uint32_t sent_bytes_ = 0;
};

