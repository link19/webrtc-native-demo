#include "stun_packet.h"
#include "byte_array.h"
#include "rtc_log.h"

StunPacket::StunPacket()
{

}

StunPacket::~StunPacket()
{

}

bool StunPacket::Parse(const uint8_t* data, size_t size)
{
	if (!IsStunPacket(data, size)) {
		return false;
	}

	ByteArray buffer;
	message_type_ = buffer.ReadUint16BE();
	message_length_ = buffer.ReadUint16BE();

	magic_cookie_ = buffer.ReadUint32BE();
	if (magic_cookie_ != STUN_MAGIC_COOKIE) {
		RTC_LOG_ERROR("Parse stun magic cookie error, magic_cookie:{}", magic_cookie_);
		return false;
	}

	buffer.ReadString(transaction_id_, STUN_TRANSACTION_ID_SIZE);

	while (buffer.Pos() < buffer.Size()) {
		uint16_t stun_attr_type = buffer.ReadUint16BE();
		uint16_t stun_attr_length = buffer.ReadUint16BE();
		if (stun_attr_length % 4 != 0) {
			RTC_LOG_ERROR("Parse stun message attr error, att:{} len:{}", stun_attr_type, stun_attr_length);
			return false;
		}

		switch (stun_attr_type)
		{
		case STUN_ATTR_USERNAME:
			buffer.ReadString(username_, stun_attr_length);
			break;
		case STUN_ATTR_PASSWORD:
			buffer.ReadString(password_, stun_attr_length);
			break;
		case STUN_ATTR_MESSAGE_INTEGRITY:
			buffer.ReadString(message_integrity_, stun_attr_length);
			break;
		case STUN_ATTR_PRIORITY:
			priority_ = buffer.ReadUint32BE();
			break;
		default:
			buffer.Seek(buffer.Pos() + stun_attr_length);
			break;
		}
	}

	return true;
}

std::string StunPacket::GetAttrUserName() const
{
	return username_;
}

std::string StunPacket::GetMessageIntegrity() const
{
	return message_integrity_;
}

std::vector<uint8_t> StunPacket::Build()
{
	ByteArray buffer;
	buffer.WriteUint16BE(message_type_);
	buffer.WriteUint16BE(message_length_);
	buffer.WriteUint32BE(STUN_MAGIC_COOKIE);
	buffer.Write(transaction_id_.c_str(), static_cast<int>(transaction_id_.length()));

	// username
	buffer.WriteUint16BE(STUN_ATTR_USERNAME);
	buffer.WriteUint16BE(username_.size());
	buffer.Write(username_.c_str(), username_.size());

	// mapped address
	buffer.WriteUint16BE(STUN_ATTR_XOR_MAPPED_ADDRESS);
	buffer.WriteUint16BE(8);
	buffer.WriteUint8(0);
	buffer.WriteUint8(0x01);
	buffer.WriteUint16BE(mapped_port_ ^ (STUN_MAGIC_COOKIE >> 16));
	buffer.WriteUint32BE(mapped_addr_ ^ STUN_MAGIC_COOKIE);

	// integrity
	buffer.WriteUint16BE(STUN_ATTR_MESSAGE_INTEGRITY);


	// fingerprint
	uint32_t c = 0xFFFFFFFF;
	uint8_t* data = buffer.Data();
	int size = buffer.Size();
	for (int index = 0; index < size; ++index) {
		c = CRC32_TABLE[(c ^ data[index]) & 0xFF] ^ (c >> 8);
	}
	uint32_t fingerprint = (c ^ 0xFFFFFFFF) ^ STUN_FINGERPRINT_XOR;

	buffer.WriteUint16BE(STUN_ATTR_FINGERPRINT);
	buffer.WriteUint16BE(STUN_ATTRIBUTE_UINT32_SIZE);
	buffer.WriteUint32BE(fingerprint);

	return std::vector<uint8_t>(buffer.Data(), buffer.Data() + buffer.Size());
}
