#include "rtcp_sender.h"
#include "byte_array.h"

RtcpSender::RtcpSender()
{

}

RtcpSender::~RtcpSender()
{

}

std::vector<uint8_t> RtcpSender::Build()
{
	return rtcp_header_.Build();
}

std::vector<uint8_t> RtcpSender::BuildSR()
{
	std::vector<uint8_t> sender_report(RTCP_SENDER_REPORT_SIZE);

	rtcp_header_.SetOption(RTCP_HEADER_OPTION_VERSION, 2);
	rtcp_header_.SetOption(RTCP_HEADER_OPTION_PADDING, 0);
	rtcp_header_.SetOption(RTCP_HEADER_OPTION_RC, 0);
	rtcp_header_.SetOption(RTCP_HEADER_OPTION_PAYLOAD_TYPE, RTCP_SENDER_REPORT_PT);
	rtcp_header_.SetOption(RTCP_HEADER_OPTION_LENGTH, RTCP_SENDER_REPORT_SIZE - RTCP_HEADER_SIZE);
	std::vector<uint8_t> header = rtcp_header_.Build();
	std::copy(header.begin(), header.end(), sender_report.begin());

	ByteArray payload;
	payload.WriteUint32BE(ssrc_);
	payload.WriteUint32BE(ntp_mword_);
	payload.WriteUint32BE(ntp_lword_);
	payload.WriteUint32BE(rtp_timestamp_);
	payload.WriteUint32BE(sent_pkt_cnt_);
	payload.WriteUint32BE(sent_bytes_);
	memcpy(sender_report.data() + RTCP_HEADER_SIZE, payload.Data(), payload.Size());

	return sender_report;
}

void RtcpSender::SetNtpTimestamp(uint32_t ntp_timestamp)
{
	ntp_mword_ = static_cast<uint32_t>(ntp_timestamp_ >> 32);
	ntp_lword_ = static_cast<uint32_t>(ntp_timestamp_ & 0xffffffff);
}
