#pragma once

#include <cstdint>
#include <vector>

#define RTCP_HEADER_OPTION_VERSION            0x01
#define RTCP_HEADER_OPTION_PADDING            0x02
#define RTCP_HEADER_OPTION_RC                 0x03
#define RTCP_HEADER_OPTION_PAYLOAD_TYPE       0x04
#define RTCP_HEADER_OPTION_LENGTH             0x05

#define RTCP_HEADER_SIZE 4

#define RTCP_SENDER_REPORT_PT    200
#define RTCP_SENDER_REPORT_SIZE  28

struct RtcpHeader
{
	uint8_t  version : 2;
	uint8_t  padding : 1;
	uint8_t  rc : 5;
	uint8_t  payload_type : 8;
	uint16_t length : 16;

	void SetOption(int opt, int value)
	{
		switch (opt)
		{
		case RTCP_HEADER_OPTION_VERSION:
			version = value;
			break;
		case RTCP_HEADER_OPTION_PADDING:
			padding = value ? 1 : 0;
			break;
		case RTCP_HEADER_OPTION_RC:
			rc = value;
			break;
		case RTCP_HEADER_OPTION_PAYLOAD_TYPE:
			payload_type = value;
			break;
		case RTCP_HEADER_OPTION_LENGTH:
			length = value;
			break;
		default:
			break;
		}
	}

	std::vector<uint8_t> Build()
	{
		std::vector<uint8_t> header(RTCP_HEADER_SIZE);
		header[0] = (version << 6) | (padding << 5) | rc;
		header[1] = payload_type;
		header[2] = length >> 8;
		header[3] = length & 0xff;
		return header;
	}
};