#pragma once

#include "rtcp_common.h"


class RtcpReceiver
{
public:
	RtcpReceiver();
	virtual ~RtcpReceiver();

	bool Parse(uint8_t* packet, size_t len);

private:
	RtcpHeader rtcp_header_ = {};
};

