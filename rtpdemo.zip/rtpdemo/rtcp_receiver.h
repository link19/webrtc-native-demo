#pragma once

#include "rtcp_common.h"


class RtcpReceiver
{
public:
	RtcpReceiver();
	virtual ~RtcpReceiver();

	bool Parse(uint8_t* packet, int len);

private:
	RtcpHeader rtcp_header_ = {};
};

