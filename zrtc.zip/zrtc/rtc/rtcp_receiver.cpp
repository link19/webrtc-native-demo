#include "rtcp_receiver.h"
#include "rtc_utils.h"

RtcpReceiver::RtcpReceiver()
{

}

RtcpReceiver::~RtcpReceiver()
{

}

bool RtcpReceiver::Parse(uint8_t* packet, int len)
{
	if (len < 4) {
		return false;
	}

	rtcp_header_.version = packet[0] >> 6;
	rtcp_header_.padding = (packet[0] >> 5) & 0x01;
	rtcp_header_.rc = packet[0] & 0x1f;
	rtcp_header_.payload_type = packet[1];
	rtcp_header_.length = ReadU16BE(packet + 2, len - 2);

	return true;
} 