'use strict';

var localVideo = document.getElementById("localVideo");
var pushBtn = document.getElementById("pushBtn");
var stopPushBtn = document.getElementById("stopPushBtn");

pushBtn.addEventListener("click", startPush);
stopPushBtn.addEventListener("click", stopPush);

var uid = "123" //$("#uid").val();
var streamName = "test"//$("#streamName").val();
var audio = "1";
var video = "1";
var offer = "";
var localStream = null;
var pc;
const config = {};
var lastConnectionState = "";

// 获取本地媒体
async function getLocalMediaStream() {
  try {
    // 请求访问用户的摄像头和麦克风
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
	localVideo.srcObject = localStream;
  } catch (error) {
    console.error('Error accessing media devices:', error);
    throw error;
  }
}

getLocalMediaStream();

function startPush() {
    console.log("send push: /api/fetchoffer");
    $.post("/api/fetchoffer",
        {"uid": uid, "stream": streamName, "type": "push", "audio": audio, "video": video},
        function(data, textStatus) {
            console.log("push response: " + JSON.stringify(data));
            if ("success" == textStatus && 0 == data.status) {
                $("#tips1").html("<font color='blue'>推流请求成功!</font>");
                console.log("offer sdp: \n" + data.offer);
                offer = data.offer;
                pushStream();
            } else {
                $("#tips1").html("<font color='red'>推流请求失败!</font>");
            }
        },
        "json"
    );
}

function sendAnswer(answer) {
    console.log("send answer: /api/sendanswer");
    $.post("/api/sendanswer",
        {"uid": uid, "stream": streamName, "answer": answer, "type": "push"},
        function(data, textStatus) {
            console.log("send answer response: " + JSON.stringify(data));
            if ("success" == textStatus && 0 == data.status) {
                $("#tips3").html("<font color='blue'>answer发送成功!</font>");
            } else {
                $("#tips3").html("<font color='red'>answer发送失败!</font>");
            }
        },
        "json"
    );
}

function stopPush() {
    console.log("send stop push: /api/stop");

    localVideo.srcObject = null;
    if (localStream && localStream.getAudioTracks()) {
        localStream.getAudioTracks()[0].stop();
    }

    if (localStream && localStream.getVideoTracks()) {
        localStream.getVideoTracks()[0].stop();
    }

    if (pc) {
        pc.close();
        pc = null;
    }

    $("#tips1").html("");
    $("#tips2").html("");
    $("#tips3").html("");

    $.post("/signaling/stoppush",
        {"uid": uid, "streamName": streamName},
        function(data, textStatus) {
            console.log("stop push response: " + JSON.stringify(data));
            if ("success" == textStatus && 0 == data.errNo) {
                $("#tips1").html("<font color='blue'>停止推流请求成功!</font>");
            } else {
                $("#tips1").html("<font color='red'>停止推流请求失败!</font>");
            }
        },
        "json"
    );

}

function pushStream() {
	// 创建 RTCPeerConnection
    pc = new RTCPeerConnection(config);
    localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
	
	// 监听连接状态变化
    pc.oniceconnectionstatechange = function(e) {
        var state = "";
        if (lastConnectionState != "") {
            state = lastConnectionState + "->" + pc.iceConnectionState;
        } else {
            state = pc.iceConnectionState;
        }

        $("#tips2").html("连接状态: " + state);
        lastConnectionState = pc.iceConnectionState;
    }
    
	// 设置Offer
	const offerData = {
		type: 'offer',
		sdp: offer
	};
    pc.setRemoteDescription(new RTCSessionDescription(offerData)).then(
        setRemoteDescriptionSuccess,
        setRemoteDescriptionError
    );
}

function setRemoteDescriptionSuccess() {
    console.log("pc set remote description success");
	pc.createAnswer().then(
		createSessionDescriptionSuccess,
		createSessionDescriptionError               
	);
}

function createSessionDescriptionSuccess(answer) {
    console.log("answer sdp: \n" + answer.sdp);
    console.log("pc set local sdp");
    pc.setLocalDescription(answer).then(
        setLocalDescriptionSuccess,
        setLocalDescriptionError
    );
    sendAnswer(answer.sdp);
}

function setLocalDescriptionSuccess() {
    console.log("set local description success");
}

function setRemoteDescriptionError(error) {
    console.log("pc set remote description error: " + error);
}

function setLocalDescriptionError(error) {
    console.log("pc set local description error: " + error);
}

function createSessionDescriptionError(error) {
    console.log("pc create answer error: " + error);
}


