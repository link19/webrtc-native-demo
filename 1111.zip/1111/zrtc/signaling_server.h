#pragma once

#include <cstdint>
#include <string>
#include <thread>
#include <functional>

extern "C" {
#include "mongoose/mongoose.h"
}

using SignalingCallback = std::function<std::string(std::string data)>;

class SignalingServer
{
public:
	SignalingServer();
	virtual ~SignalingServer();

	void SetCallback(const SignalingCallback& callback);

	bool Init(uint16_t port, std::string ip = "localhost");
	void Destroy();

private:
	static void OnEvent(struct mg_connection* conn, int ev, void* ev_data);

	struct mg_mgr mgr_ = {};
	struct mg_connection* connection_ = nullptr;
	std::unique_ptr<std::thread> event_thread_;
	SignalingCallback signaling_callback_;
};

