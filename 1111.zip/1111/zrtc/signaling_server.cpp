#include "signaling_server.h"

static const char* http_root_dir = "./jswebrtc";
static const char* rtc_api_play = "/rtc/v1/play/";

SignalingServer::SignalingServer()
{

}
SignalingServer::~SignalingServer()
{
	Destroy();
}

bool SignalingServer::Init(uint16_t port, std::string ip)
{
	if (connection_) {
		return false;
	}

	std::string url = "http://" + ip + ":" + std::to_string(port);
	mg_mgr_init(&mgr_);
	connection_ = mg_http_listen(&mgr_, url.c_str(), SignalingServer::OnEvent, this);
	if (!connection_) {
		return false;
	}

	event_thread_.reset(new std::thread([this] {
		while (connection_) {
			mg_mgr_poll(&mgr_, 1000);
		}
		}));

	return true;
}

void SignalingServer::Destroy()
{
	if (connection_) {
		event_thread_->join();
		event_thread_.reset();
		mg_mgr_free(&mgr_);
		connection_ = nullptr;
	}
}

void SignalingServer::SetCallback(const SignalingCallback& callback)
{
	signaling_callback_ = callback;
}

void SignalingServer::OnEvent(struct mg_connection* conn, int ev, void* ev_data)
{
	SignalingServer* server = reinterpret_cast<SignalingServer*>(conn->fn_data);
	if (!server) {
		return;
	}

	if (ev == MG_EV_HTTP_MSG) {
		struct mg_http_message* hm = (struct mg_http_message*)ev_data;
		if (mg_match(hm->uri, mg_str(rtc_api_play), NULL)) {
			std::string result;
			if (server->signaling_callback_ && hm->body.len > 0) {
				result = server->signaling_callback_(std::string(hm->body.buf, hm->body.len));
			}

			mg_printf(conn,
				"HTTP/1.1 200 OK\r\n"
				"Access-Control-Allow-Origin: *\r\n"
				"Access-Control-Allow-Methods: POST, GET, OPTIONS\r\n"
				"Content-Length: %d\r\n"
				"Content-Type: text/plain\r\n"
				"Connection: close\r\n\r\n"
				"%s", result.size(), result.c_str());
		}
		else {
			struct mg_http_serve_opts opts = { };
			opts.root_dir = http_root_dir;
			mg_http_serve_dir(conn, (mg_http_message*)ev_data, &opts);
		}
	}
}