#include "signaling_server.h"
#include "rtc_server.h"
#include "rtc_log.h"
#include "rtc_utils.h"
#include "json/json.hpp"
#include "avcodec/h264_encoder.h"
#include "capture/screen_capture.h"
#include "capture/d3d11_screen_capture.h"
#include "capture/audio_capture.h"
#include "avcodec/opus_encoder.h"
#include "H264Parser.h"
// signal server: http://127.0.0.1:8000
// webrtc url: webrtc://127.0.0.1:8000/live/livestream

static uint8_t* h264_find_nalu(uint8_t* buf_start, uint8_t* buf_end) {

	uint8_t* p = buf_start + 2;

	while (p < buf_end) {

		if (*(p - 2) == 0x00 && *(p - 1) == 0x00 && *p == 0x01)
			return p + 1;
		p++;
	}

	return buf_end;
}

int main(int argc, char** argv)
{
	uint16_t signaling_port = 8000;
	std::string local_ip = "127.0.0.1";
	SignalingServer signaling_server;

#if 0
	std::vector<std::string> address = xop::NetInterface::GetLocalIPAddress();
	if (!address.empty()) {
		local_ip = address[0];
	}
#endif

	if (!signaling_server.Init(signaling_port, local_ip)) {
		return -1;
	}

	RTC_LOG_INFO("start signaling server succeed, ip:{} port:{}", local_ip, signaling_port);

	RtcServer rtc_server;
	RtcConfig rtc_config;
	rtc_config.enable_h264 = true;
	rtc_config.enable_opus = true;
	rtc_config.local_ip = local_ip;
	if (!rtc_server.Init(rtc_config)) {
		return -2;
	}

	RTC_LOG_INFO("start rtc server succeed, ip:{}", local_ip);

	signaling_server.SetCallback([&rtc_server](std::string data) {
		RTC_LOG_INFO("recv request data:{} \r\n\r\n", data);

		// response
		nlohmann::json response;
		response["code"] = 0;
		response["server"] = "zrtc";

		// parse request
		nlohmann::json result = nlohmann::json::parse(data);
		std::string streamurl = result["streamurl"];
		std::string offer = result["sdp"];
		auto pos = streamurl.find("webrtc://");
		if (pos == std::string::npos) {
			RTC_LOG_INFO("prse streamurl error, url:{}", streamurl);
			response["code"] = -1;
			return response.dump();
		}
		auto stream_name = streamurl.substr(pos + strlen("webrtc://"));
		pos = stream_name.find("/");
		if (pos != std::string::npos) {
			stream_name = stream_name.substr(pos);
		}

		// send answer
		std::string answer;
		rtc_server.OnRequest(stream_name, offer, answer);
		response["sdp"] = answer;
		return response.dump();
	});

	DX::Image image;
	std::shared_ptr<DX::ScreenCapture> screen_capture(new DX::D3D11ScreenCapture());
	screen_capture->Init(0);
	if (!screen_capture->Capture(image)) {
		RTC_LOG_ERROR("capture image failed.");
	}

	ffmpeg::H264Encoder h264_encoder;
	AVConfig av_config;
	av_config.video.framerate = 25;
	av_config.video.bitrate = 1000000;
	av_config.video.gop = 25;
	av_config.video.format = AV_PIX_FMT_BGRA;
	av_config.video.width = image.width;
	av_config.video.height = image.height;

	if (!h264_encoder.Init(av_config)) {
		return -1;
	}

	std::thread capture_audio([&rtc_server] {
		AudioCapture audio_capture;
		audio_capture.Init();
		OpusAudioEncoder opus_encoder;
		AVConfig audio_config;
		audio_config.audio.bitrate = 64000;
		audio_config.audio.channels = audio_capture.GetChannels();
		audio_config.audio.samplerate = audio_capture.GetSamplerate();
		audio_config.audio.format = AV_SAMPLE_FMT_S16;
		opus_encoder.Init(audio_config);
		std::shared_ptr<uint8_t> pcm_buffer(new uint8_t[48000 * 8], std::default_delete<uint8_t[]>());
		int frame_samples = 48000 / 50;
		while (1) {
			//uint8_t* data, uint32_t samples
			int samples = audio_capture.Read(pcm_buffer.get(), frame_samples);
			if (samples > 0) {
				auto opus_frame = opus_encoder.Encode((int16_t*)pcm_buffer.get(), samples);
				if (opus_frame.size() > 0)
					rtc_server.SendAudioFrame(opus_frame.data(), opus_frame.size());
			}
			xop::Timer::Sleep(1);
		}
	});

	struct MediaInfo
	{
		std::shared_ptr<uint8_t> sps;
		std::shared_ptr<uint8_t> pps;
		std::shared_ptr<uint8_t> sei;
		uint32_t sps_size = 0;
		uint32_t pps_size = 0;
		uint32_t sei_size = 0;
	};

	while (1) {
		xop::Timestamp use_time;
		DX::Image image;
		if (screen_capture->Capture(image)) {
			auto pkt = h264_encoder.Encode(image.bgra.data(), image.width, image.height, image.bgra.size());
			if (pkt) {
				if (pkt->data[4] == 0x65) {
					uint8_t* extradata = h264_encoder.GetAVCodecContext()->extradata;
					int extradata_size = h264_encoder.GetAVCodecContext()->extradata_size;
					if (extradata_size <= 0) {
						printf("Get video specific config failed. \n");
					}

					MediaInfo mediaInfo;
					xop::Nal sps = xop::H264Parser::findNal((uint8_t*)extradata, extradata_size);
					if (sps.first != nullptr && sps.second != nullptr && ((*sps.first & 0x1f) == 7)) {
						mediaInfo.sps_size = sps.second - sps.first + 1;
						mediaInfo.sps.reset(new uint8_t[mediaInfo.sps_size], std::default_delete<uint8_t[]>());
						memcpy(mediaInfo.sps.get(), sps.first, mediaInfo.sps_size);

						xop::Nal pps = xop::H264Parser::findNal(sps.second, extradata_size - (sps.second - (uint8_t*)extradata));
						if (pps.first != nullptr && pps.second != nullptr && ((*pps.first & 0x1f) == 8)) {
							mediaInfo.pps_size = pps.second - pps.first + 1;
							mediaInfo.pps.reset(new uint8_t[mediaInfo.pps_size], std::default_delete<uint8_t[]>());
							memcpy(mediaInfo.pps.get(), pps.first, mediaInfo.pps_size);
						}
					}

					rtc_server.SendVideoFrame(mediaInfo.sps.get(), mediaInfo.sps_size);
					rtc_server.SendVideoFrame(mediaInfo.pps.get(), mediaInfo.pps_size);
				}
				//RTC_LOG_INFO("h264 frame: {} {:x} {:x} {:x} {:x} {:x}", pkt->size, \
					pkt->data[0], pkt->data[1], pkt->data[2], pkt->data[3], pkt->data[4]);
				rtc_server.SendVideoFrame(pkt->data, pkt->size);
			}
		}

		uint32_t sleep_time = 40 > use_time.Elapsed() ? 40 - use_time.Elapsed() : 1;
		xop::Timer::Sleep(sleep_time);
	}

	return 0;
}