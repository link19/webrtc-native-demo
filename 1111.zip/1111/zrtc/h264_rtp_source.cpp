#include "h264_rtp_source.h"

static size_t find_nalu_start_code_size(uint8_t* frame_data, size_t frame_size)
{
    if (frame_size <= 4) {
        return 0;
    }
    if (frame_data[0] == 0x00 && frame_data[1] == 0x00 && frame_data[2] == 0x01) {
        return 3;
    }

    if (frame_data[0] == 0x00 && frame_data[1] == 0x00 && frame_data[2] == 0x00 && frame_data[3] == 0x01) {
        return 4;
    }
    return 0;
}

static uint8_t* find_nalu(uint8_t* buf_start, uint8_t* buf_end) {

    uint8_t* p = buf_start + 2;

    while (p < buf_end) {

        if (*(p - 2) == 0x00 && *(p - 1) == 0x00 && *p == 0x01)
            return p + 1;
        p++;
    }

    return buf_end;
}

H264RtpSource::H264RtpSource(uint32_t ssrc, uint32_t payload_type)
	: RtpSource(ssrc, payload_type)
{
    clock_rate_ = RTC_H264_CLOCK_RATE;
}

H264RtpSource::~H264RtpSource()
{

}

#include "rtc_log.h"
typedef struct NaluHeader {

    uint8_t type : 5;
    uint8_t nri : 2;
    uint8_t f : 1;
} NaluHeader;

typedef struct FuHeader {

    uint8_t type : 5;
    uint8_t r : 1;
    uint8_t e : 1;
    uint8_t s : 1;
} FuHeader;

void H264RtpSource::InputFrame(uint8_t* frame_data, size_t frame_size)
{
    std::list<RtpPacketPtr> rtp_pkts;

    size_t start_code_size = find_nalu_start_code_size(frame_data, frame_size);
    uint8_t nalu_type = frame_data[start_code_size] & 0x1f;

    uint32_t timestamp = GetTimestamp();
    //timestamp += 90000 / 30;
    SetTimestamp(timestamp);
    
    uint32_t max_rtp_payload_size = RTC_MAX_RTP_PACKET_LENGTH - RTP_HEADER_SIZE;
#if 1
    if (nalu_type == RTC_H264_FRAME_TYPE_SPS) {
        sps_.reset(new uint8_t[frame_size], std::default_delete<uint8_t[]>());
        sps_size_ = frame_size;
        memcpy(sps_.get(), frame_data, sps_size_);
        return;
    }
    else if (nalu_type == RTC_H264_FRAME_TYPE_PPS) {
        pps_.reset(new uint8_t[frame_size], std::default_delete<uint8_t[]>());
        pps_size_ = frame_size;
        memcpy(pps_.get(), frame_data, pps_size_);
        return;
    }

    if (nalu_type == RTC_H264_FRAME_TYPE_IDR) {
        std::shared_ptr<RtpPacket> rtp_pkt(new RtpPacket());
        uint8_t* rtp_data_ = rtp_pkt->data.get();
        SetMarker(0);
        SetSequence(sequence_++);
        BuildHeader(rtp_pkt);
        rtp_data_ += RTP_HEADER_SIZE;
        rtp_data_[0] = sps_.get()[4] & (~0x1f) | 24;
        rtp_data_ += 1;
        WriteUint16BE(rtp_data_, sps_size_ - 4);
        rtp_data_ += 2;
        memcpy(rtp_data_, sps_.get() + 4, sps_size_ - 4);
        rtp_data_ += sps_size_ - 4;

        //rtp_data_[0] = pps_.get()[4] & (~0x1f) | 24;
        //rtp_data_ += 1;
        WriteUint16BE(rtp_data_, pps_size_ );
        rtp_data_ += 2;
        memcpy(rtp_data_, pps_.get() , pps_size_ );
        rtp_data_ += pps_size_ ;

        rtp_pkt->data_size = RTP_HEADER_SIZE + sps_size_ + pps_size_ - 8 + 5;
        rtp_pkts.push_back(rtp_pkt);
    }
#endif
    frame_size -= start_code_size;
    frame_data += start_code_size;

    //RTC_LOG_INFO("nal: {}", frame_data[0] & 0x1f);
    
    if (frame_size < max_rtp_payload_size) {
        std::shared_ptr<RtpPacket> rtp_pkt(new RtpPacket());
        SetMarker(1);
        SetSequence(sequence_++);
        BuildHeader(rtp_pkt);
        memcpy(rtp_pkt->data.get() + RTP_HEADER_SIZE, frame_data, frame_size);
        rtp_pkt->data_size = RTP_HEADER_SIZE + static_cast<uint32_t>(frame_size);
        rtp_pkts.push_back(rtp_pkt);
    }
    else {
        uint8_t type = frame_data[0] & 0x1f;
        uint8_t nri = (frame_data[0] & 0x60) >> 5;

        uint8_t fu_a_size = 2;
        uint8_t fu_a[2] = { 0 };
        //fu_a[0] = (frame_data[0] & 0xE0) | 28;
        //fu_a[1] = 0x80 | (frame_data[0] & 0x1f);
        frame_data += 1;
        frame_size -= 1;

        NaluHeader* fu_indicator = (NaluHeader*)fu_a;
        FuHeader* fu_header = (FuHeader*)fu_a  + sizeof(NaluHeader);
        fu_header->s = 1;

        while (frame_size + fu_a_size > max_rtp_payload_size) {
            fu_indicator->type = 28;
            fu_indicator->nri = nri;
            fu_indicator->f = 0;
            fu_header->type = type;
            fu_header->r = 0;

            fu_header->e = 0;

            std::shared_ptr<RtpPacket> rtp_pkt(new RtpPacket());
            SetMarker(0);
            SetSequence(sequence_++);
            BuildHeader(rtp_pkt);
            rtp_pkt->data.get()[RTP_HEADER_SIZE + 0] = fu_a[0];
            rtp_pkt->data.get()[RTP_HEADER_SIZE + 1] = fu_a[1];
            memcpy(rtp_pkt->data.get() + RTP_HEADER_SIZE + fu_a_size, frame_data, max_rtp_payload_size - fu_a_size);
            rtp_pkt->data_size = RTP_HEADER_SIZE + max_rtp_payload_size;
            rtp_pkts.push_back(rtp_pkt);

            frame_data += max_rtp_payload_size - fu_a_size;
            frame_size -= max_rtp_payload_size - fu_a_size;
            //fu_a[1] &= ~0x80;
            fu_header->s = 0;
        }

        {
            std::shared_ptr<RtpPacket> rtp_pkt(new RtpPacket());
            SetMarker(1);
            SetSequence(sequence_++);
            BuildHeader(rtp_pkt);
            //fu_a[1] |= 0x40;
            fu_header->e = 1;
            rtp_pkt->data.get()[RTP_HEADER_SIZE + 0] = fu_a[0];
            rtp_pkt->data.get()[RTP_HEADER_SIZE + 1] = fu_a[1];
            memcpy(rtp_pkt->data.get() + RTP_HEADER_SIZE + fu_a_size, frame_data, frame_size);
            rtp_pkt->data_size = RTP_HEADER_SIZE + fu_a_size + static_cast<uint32_t>(frame_size);
            rtp_pkts.push_back(rtp_pkt);
        }
    }

    if (rtp_pkts.size() > 0 && send_pkt_callback_) {
        send_pkt_callback_(rtp_pkts);
    }
}


